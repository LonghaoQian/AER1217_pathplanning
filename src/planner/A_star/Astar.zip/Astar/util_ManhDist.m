% Manhatten distance
function h = util_ManhDist(x_start,y_start,x_destination, y_destination)

h = abs(x_start-x_destination)+abs(y_start-y_destination);


