function m_2 = findweight(m_1, m, x)
    m_temp = m_1;
    m_2 = m_1;
    for i = 1 : x
        m_3 = m_1 + ones(size(m_1))*i*m;% temp variable for an increase of mass
        for j = 1 : max(size(m_3))
            m_same = m_3(j)*ones(size(m_temp)) - m_temp;
            % determine whether m_3(j) has already existed in the previous
            % combination
            J =find(~m_same);
            if( min(size(J)) == 0 )% if not means that m_3(j) is a new mass combination
                m_2 = [m_2 m_3(j)];% if nonzero diff, add the result to m_2 vector
            end
        end
        m_temp = m_2;% update temp
    end
    m_2 = sort(m_2);
end