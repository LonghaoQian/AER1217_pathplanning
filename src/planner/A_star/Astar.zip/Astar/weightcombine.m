% mass



clear all
m_sq = [1 2 5 9 10];
x_sq = [3 3 2 6 1];
%m_sq = [2 3 5];
%x_sq = [3 2 3];

m_1 = m_sq(1)*(1:1:x_sq(1));


for i = 2 : max(size(m_sq))
    
    m_1 = findweight(m_1, m_sq(i), x_sq(i));
    
end


